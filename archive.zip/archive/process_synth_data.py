#!/usr/bin/env python3
import argparse
import pandas as pd
import json
import os


def flatten_label_xai(d):
    out = {}
    for k, v in d.items():
        out[k] = v.get("label")   # keep label
        out[f"{k}_XAI"] = v.get("xai")  # keep explanation
    return out


def load_data(input_file):
    rows = []
    with open(input_file, "r", encoding="utf-8") as file:
        for line in file:
            try:
                data = json.loads(line)
                rows.append(data["output_json"]["items"])
            except Exception:
                pass
    return rows


def main():
    parser = argparse.ArgumentParser(description="Process synth JSONL into compact & full CSVs")
    parser.add_argument("--input", required=True, help="Path to input JSONL file")
    parser.add_argument("--output", required=True, help="Base name for output CSV files")
    args = parser.parse_args()

    # Load and flatten
    row_data = load_data(args.input)
    flat_data = [flatten_label_xai(r) for r in row_data]
    df = pd.DataFrame(flat_data)

    # Normalize: True/False -> 1/0
    df = df.replace({True: 1, False: 0})
    df = df.reindex(sorted(df.columns), axis=1)

    # Full version
    full_out = args.output.replace(".csv", "_full.csv")
    df.to_csv(full_out, index=False)

    # Compact version (drop XAI columns)
    compact_df = df[[c for c in df.columns if not c.endswith("_XAI")]]
    compact_out = args.output.replace(".csv", "_compact.csv")
    compact_df.to_csv(compact_out, index=False)

    print(f"✅ Exported: {full_out} and {compact_out}")


if __name__ == "__main__":
    main()
