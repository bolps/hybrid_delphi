library(psych)
library(readr)
library(dplyr)

# Read data
df_all <- read_csv("synthdata/gpt5mini_results_compact.csv")

# Overall Cronbach Alpha
alpha(df_all)

# Cronbach Alpha by dimension
df_d1 <- df_all %>% select(IT23,
                           IT45,
                           IT46,
                           IT48,
                           IT20,
                           IT21,
                           IT15,
                           IT25,
                           IT47)
alpha(df_d1)

df_d2 <- df_all %>% select(IT13,
                           IT14,
                           IT16,
                           IT27,
                           IT30,
                           IT31,
                           IT39,
                           IT41,
                           IT29)
alpha(df_d2)

df_d2red <- df_d2 %>% select(IT45, IT46, IT48)
alpha(df_d2red)$total

df_d3 <- df_all %>% select(IT09, 
                           IT19)
alpha(df_d3)

# This is the positive dimension, should be reverted
df_d4 <- df_all %>% select(IT01,
                           IT02,
                           IT04,
                           IT44,
                           IT06,
                           IT07,
                           IT08,
                           IT03,
                           IT05)

alpha(df_d4)

df_d5 <- df_all %>% select(IT34,
                           IT35,
                           IT36,
                           IT40,
                           IT37)
alpha(df_d5)

df_d6 <- df_all %>% select(IT10,
                           IT12,
                           IT26,
                           IT11)
alpha(df_d6)

df_d7 <- df_all %>% select(IT32,
                           IT38,
                           IT42,
                           IT33)
alpha(df_d7)

df_all_clean <- df_all[, !(names(df_all) %in% c("IT04",
                                                "IT06",
                                                "IT07",
                                                "IT08",
                                                "IT02",
                                                "IT05",
                                                "IT44"))]

fa.parallel(df_all_clean, fm = "minres", fa = "fa")

# Example: factor analysis with 3 factors
efa_result <- fa(df_all_clean, nfactors = 6, rotate = "oblimin", fm = "minres")

print(efa_result, cut=0.5)


library(blavaan)
library(bayesplot)

# IT04 and IT07 removed due to zero variance
model <- '
  # latent factors
  F1 =~ IT10 + IT12 + IT22 + IT24 + IT25 + IT26 + IT15
  F2 =~ IT45 + IT46 + IT48
  F3 =~ IT09 + IT19
  F4 =~ IT01 + IT03 + IT06 + IT08
  F5 =~ IT40 + IT43
  F6 =~ IT14 + IT16 + IT28 + IT29 + IT30 + IT39 + IT41 + IT27
  F7 =~ IT32 + IT42
  F8 =~ IT33 + IT34 + IT35 + IT36 + IT37
'
fit <- bcfa(
  model,
  data = df_all,
  std.lv = TRUE,        # identifies factors by setting var(F) = 1 (recommended)
  n.chains = 2,
  burnin = 1000,
  sample = 1000         # post-burn-in draws per chain
)

summary(fit, standardized = TRUE)        # posterior means, SDs, 95% CrIs, std loadings
fitMeasures(fit, "ppp")                  # posterior predictive p-value (model fit)