#!/usr/bin/env python3
"""
Persona Generator for Relationship Abuse Key Types + Demographics
-------------------------------------------------
Generates JSON objects with boolean flags for the key abuse categories and some
basic demographic attributes. You control the probability for each abuse key
(type -> Bernoulli trial).

Features
- Abuse categories with independent probabilities (0.0–1.0)
- New categories: **social_isolation**
- Demographics with **realistic bias** (configurable profiles):
  * age: truncated normal (mean≈35, sd≈10) → integer 18–60
  * marital_status: age-conditional distribution
  * ethnicity: weighted by a chosen profile (global_generic default)
  * children: probability conditioned on age & marital_status (overrideable)
- Fake source subreddit (sampled from toxicrelationships, abusiverelationships,
  relationship_advice, domestic_violence, offmychest)
- Optional seed for reproducibility
- Optional guarantee at least one abuse category is True
- Outputs as JSON Lines (one persona per line) or a single JSON array
- Validates inputs and reports unknown keys

Key Abuse Types (JSON fields)
- physical_abuse
- sexual_abuse
- psychological_emotional_abuse
- financial_abuse
- digital_technological_abuse
- spiritual_cultural_abuse
- neglect_withholding_care
- controlling_behavior
- social_isolation

Usage examples
--------------
# Generate 5 personas with defaults
python persona_generator.py --n 5 --seed 42

# Custom abuse probabilities, children prob, EU demographic bias
python persona_generator.py \
  --demo-profile EU_aggregate \
  --probs '{
    "psychological_emotional_abuse": 0.4,
    "children": 0.55,
    "social_isolation": 0.25
  }' \
  --n 10 --seed 123

# Override ethnicity weights inline (JSON mapping)
python persona_generator.py \
  --ethnicity-weights '{"White":0.6,"Black":0.1,"Hispanic/Latino":0.15,"Asian":0.1,"Indigenous":0.03,"Other":0.02}' \
  --n 3 --json-array

"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
from typing import Dict, List, Any, Tuple

try:
    import yaml  # Optional, only if user provides a YAML config
except Exception:  # pragma: no cover
    yaml = None

# ---- Canonical keys and defaults -------------------------------------------------
ABUSE_KEYS: List[str] = [
    "physical_abuse",
    "sexual_abuse",
    "psychological_emotional_abuse",
    "financial_abuse",
    "digital_technological_abuse",
    "spiritual_cultural_abuse",
    "neglect_withholding_care",
    "controlling_behavior",
    "social_isolation",
]

ALL_KEYS: List[str] = ABUSE_KEYS + ["children"]

DEFAULT_PROBS: Dict[str, float] = {
    "physical_abuse": 0.15,
    "sexual_abuse": 0.10,
    "psychological_emotional_abuse": 0.35,
    "financial_abuse": 0.20,
    "digital_technological_abuse": 0.25,
    "spiritual_cultural_abuse": 0.08,
    "neglect_withholding_care": 0.12,
    "controlling_behavior": 0.30,
    "social_isolation": 0.20,
    "children": 0.50,
}

MARITAL_STATUSES = ["single", "married", "divorced", "widowed", "cohabiting"]
ETHNICITIES = ["White", "Black", "Hispanic/Latino", "Asian", "Indigenous", "Other"]

FAKE_SOURCES = [
    "toxicrelationships",
    "abusiverelationships",
    "relationship_advice",
    "domestic_violence",
    "offmychest",
]

# Demographic profiles (rough, high-level priors; overrideable)
DEMO_PROFILES: Dict[str, Dict[str, Any]] = {
    "global_generic": {
        "ethnicity_weights": {
            "White": 0.38,
            "Black": 0.17,
            "Hispanic/Latino": 0.18,
            "Asian": 0.22,
            "Indigenous": 0.03,
            "Other": 0.02,
        },
    },
    "US_2020ish": {
        "ethnicity_weights": {
            "White": 0.60,
            "Black": 0.12,
            "Hispanic/Latino": 0.19,
            "Asian": 0.06,
            "Indigenous": 0.02,
            "Other": 0.01,
        },
    },
    "EU_aggregate": {
        "ethnicity_weights": {
            "White": 0.72,
            "Black": 0.09,
            "Hispanic/Latino": 0.09,
            "Asian": 0.07,
            "Indigenous": 0.01,
            "Other": 0.02,
        },
    },
}

AGE_PARAMS = {"mean": 35.0, "sd": 10.0, "min": 18, "max": 60}

MARITAL_BY_AGE_BAND: Dict[Tuple[int, int], Dict[str, float]] = {
    (18, 24): {"single": 0.65, "cohabiting": 0.20, "married": 0.12, "divorced": 0.02, "widowed": 0.01},
    (25, 34): {"single": 0.35, "cohabiting": 0.25, "married": 0.35, "divorced": 0.04, "widowed": 0.01},
    (35, 44): {"single": 0.20, "cohabiting": 0.15, "married": 0.55, "divorced": 0.08, "widowed": 0.02},
    (45, 54): {"single": 0.18, "cohabiting": 0.12, "married": 0.52, "divorced": 0.14, "widowed": 0.04},
    (55, 60): {"single": 0.20, "cohabiting": 0.08, "married": 0.45, "divorced": 0.20, "widowed": 0.07},
}

CHILDREN_BASE_BY_AGE: Dict[Tuple[int, int], float] = {
    (18, 24): 0.20,
    (25, 34): 0.45,
    (35, 44): 0.70,
    (45, 54): 0.75,
    (55, 60): 0.65,
}
CHILDREN_ADJ_BY_MARITAL: Dict[str, float] = {
    "single": -0.15,
    "cohabiting": +0.10,
    "married": +0.20,
    "divorced": +0.10,
    "widowed": +0.15,
}

# ---- Core generation -------------------------------------------------------------

def validate_probabilities(p: Dict[str, Any]) -> Dict[str, float]:
    unknown = sorted(set(p.keys()) - set(ALL_KEYS))
    if unknown:
        raise ValueError(
            f"Unknown probability keys: {unknown}. Allowed keys are: {ALL_KEYS}"
        )

    merged = {**DEFAULT_PROBS}
    for k, v in p.items():
        try:
            fv = float(v)
        except Exception:
            raise ValueError(f"Probability for '{k}' must be a number (got {v!r})")
        if not (0.0 <= fv <= 1.0) or math.isnan(fv):
            raise ValueError(
                f"Probability for '{k}' must be in [0, 1] (got {fv})"
            )
        merged[k] = fv

    return merged


def bernoulli_draw(p: float) -> bool:
    return random.random() < max(0.0, min(1.0, p))


def truncnorm_int(mean: float, sd: float, lo: int, hi: int) -> int:
    while True:
        x = random.gauss(mean, sd)
        if lo - 0.5 <= x <= hi + 0.5:
            return int(round(min(max(x, lo), hi)))


def weighted_choice(weights: Dict[str, float]) -> str:
    items = list(weights.items())
    total = sum(max(0.0, w) for _, w in items)
    if total <= 0:
        return random.choice([k for k, _ in items])
    r = random.random() * total
    acc = 0.0
    for k, w in items:
        acc += max(0.0, w)
        if r <= acc:
            return k
    return items[-1][0]


def pick_age_band(age: int) -> Tuple[int, int]:
    for (a, b) in MARITAL_BY_AGE_BAND.keys():
        if a <= age <= b:
            return (a, b)
    return (55, 60)


def sample_marital_status(age: int) -> str:
    band = pick_age_band(age)
    return weighted_choice(MARITAL_BY_AGE_BAND[band])


def sample_children_prob(age: int, marital_status: str, base_children_p: float) -> float:
    band = pick_age_band(age)
    base = CHILDREN_BASE_BY_AGE.get(band, base_children_p)
    adj = CHILDREN_ADJ_BY_MARITAL.get(marital_status, 0.0)
    p = 0.5 * base + 0.5 * base_children_p
    p += adj
    return max(0.0, min(1.0, p))


def generate_persona(probabilities: Dict[str, float], ensure_one: bool = False, *, demo_profile: str = "global_generic", ethnicity_weights_override: Dict[str, float] | None = None) -> Dict[str, Any]:
    draws = {k: bernoulli_draw(probabilities[k]) for k in ABUSE_KEYS}
    if ensure_one and not any(draws.values()):
        top_key = max(ABUSE_KEYS, key=lambda k: probabilities[k])
        draws[top_key] = True

    age = truncnorm_int(AGE_PARAMS["mean"], AGE_PARAMS["sd"], AGE_PARAMS["min"], AGE_PARAMS["max"])
    marital_status = sample_marital_status(age)

    profile = DEMO_PROFILES.get(demo_profile, DEMO_PROFILES["global_generic"])
    eth_weights = dict(profile.get("ethnicity_weights", {}))
    if ethnicity_weights_override:
        for k, v in ethnicity_weights_override.items():
            if k in ETHNICITIES:
                eth_weights[k] = float(v)
    for k in ETHNICITIES:
        eth_weights.setdefault(k, 0.0)
    ethnicity = weighted_choice(eth_weights)

    children_p = sample_children_prob(age, marital_status, probabilities["children"])
    children = bernoulli_draw(children_p)

    fake_source = random.choice(FAKE_SOURCES)

    return {
        **draws,
        "age": age,
        "marital_status": marital_status,
        "ethnicity": ethnicity,
        "children": children,
        "source": fake_source,
    }

# ---- I/O helpers -----------------------------------------------------------------

def load_probs_from_config(path: str) -> Dict[str, float]:
    ext = os.path.splitext(path)[1].lower()
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    if ext in {".json", ".jsn"}:
        data = json.loads(text)
    elif ext in {".yaml", ".yml"}:
        if yaml is None:
            raise RuntimeError("PyYAML not available. Install pyyaml or use JSON.")
        data = yaml.safe_load(text)
    else:
        try:
            data = json.loads(text)
        except Exception:
            if yaml is None:
                raise
            data = yaml.safe_load(text)
    if not isinstance(data, dict):
        raise ValueError("Config file must contain a JSON/YAML object (mapping).")
    return validate_probabilities(data)


def parse_inline_probs(s: str) -> Dict[str, float]:
    try:
        data = json.loads(s)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"--probs must be valid JSON (error: {e}). Tip: wrap keys in double quotes."
        ) from e
    if not isinstance(data, dict):
        raise ValueError("--probs JSON must be an object mapping keys to probabilities.")
    return validate_probabilities(data)


# ---- CLI -------------------------------------------------------------------------

def build_argparser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="Generate personas with boolean abuse-category flags and demographics (JSON).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--n", type=int, default=1, help="Number of personas to generate")
    ap.add_argument("--seed", type=int, default=None, help="Random seed for reproducibility")
    ap.add_argument(
        "--probs",
        type=str,
        default=None,
        help="Inline JSON mapping key -> probability (overrides defaults).",
    )
    ap.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to JSON/YAML file with probability mapping.",
    )
    ap.add_argument(
        "--ensure-one",
        action="store_true",
        help="Ensure at least one abuse category is True by flipping the highest-prob key if needed.",
    )
    ap.add_argument(
        "--json-array",
        action="store_true",
        help="Emit a single JSON array instead of newline-delimited JSON (NDJSON)",
    )
    ap.add_argument(
        "--demo-profile",
        type=str,
        default="global_generic",
        choices=sorted(list(DEMO_PROFILES.keys())),
        help="Demographic profile to bias ethnicity weighting.",
    )
    ap.add_argument(
        "--ethnicity-weights",
        type=str,
        default=None,
        help="Inline JSON mapping ethnicity -> weight (overrides profile).",
    )
    return ap


def main(argv: List[str] | None = None) -> int:
    ap = build_argparser()
    args = ap.parse_args(argv)

    if args.seed is not None:
        random.seed(args.seed)

    if args.probs and args.config:
        ap.error("Use either --probs or --config, not both.")

    if args.config:
        probabilities = load_probs_from_config(args.config)
    elif args.probs:
        probabilities = parse_inline_probs(args.probs)
    else:
        probabilities = DEFAULT_PROBS.copy()

    ethnicity_override = None
    if args.ethnicity_weights:
        try:
            ethnicity_override = json.loads(args.ethnicity_weights)
            if not isinstance(ethnicity_override, dict):
                raise ValueError("--ethnicity-weights must be a JSON object mapping ethnicity->weight")
        except json.JSONDecodeError as e:
            raise SystemExit(f"Invalid --ethnicity-weights JSON: {e}")

    personas: List[Dict[str, Any]] = [
        generate_persona(
            probabilities,
            ensure_one=args.ensure_one,
            demo_profile=args.demo_profile,
            ethnicity_weights_override=ethnicity_override,
        )
        for _ in range(args.n)
    ]

    if args.json_array:
        json.dump(personas, sys.stdout, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        for row in personas:
            sys.stdout.write(json.dumps(row, ensure_ascii=False) + "\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
