#!/usr/bin/env python3
"""
Generate synthetic narratives (full posts) from personas using Ollama via the OpenAI Python SDK.

Input:
  --personas: path to a JSON array of persona dicts (one per persona)
  --model:    Ollama model name, e.g. "llama3.1:8b" (must exist in `ollama list`)
  --out:      path to write JSON array: [{"narrative_id": "...", "text": "...", "persona": {...}}, ...]

Usage example:
  export OPENAI_BASE_URL="http://localhost:11434/v1"
  export OPENAI_API_KEY="ollama"  # any non-empty string works for Ollama
  python generate_posts_with_ollama.py \
      --personas personas.json \
      --model "llama3.1:8b" \
      --out narratives.json
"""
from __future__ import annotations
import argparse, json, os, sys, time, uuid
from typing import List, Dict
from openai import OpenAI

SYS_PROMPT = """You are a careful, empathetic writer. You will receive a JSON persona with boolean flags
for relationship abuse dimensions plus demographics (age, marital status, etc.). Write a *first-person*
English narrative post (300–500 words) that plausibly reflects *only what the flags and demographics suggest*.
Rules:
- Do not fabricate details that contradict the booleans; if a flag is False, avoid implying it happened.
- Keep it realistic, grounded, and readable, like a personal post someone might share in a forum.
- Include day-to-day texture (messages, outings, arguments) but avoid gratuitous graphic detail.
- Do not include the persona JSON or any metadata in the output; output only the narrative text.
"""

# A light mapping helper to remind the model of what flags mean.
# (This is NOT constraining—just orienting. Adjust names to match your generator if needed.)
FLAG_GUIDE = """
Flag guide (True means signs likely appear; False means they should not be implied):
- emotional_abuse, verbal_abuse, jealousy_possessiveness, controlling_behavior,
- economic_abuse, social_isolation, stalking_surveillance, physical_violence, sexual_coercion
"""

def build_user_prompt(persona: Dict) -> str:
    return (
        "Persona JSON:\n"
        + json.dumps(persona, ensure_ascii=False, indent=2)
        + "\n\n"
        + FLAG_GUIDE
        + "\n\nWrite the narrative now."
    )

def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--personas", required=True, help="Path to JSON array of personas.")
    ap.add_argument("--model", required=True, help='Ollama model name, e.g. "llama3.1:8b"')
    ap.add_argument("--out", required=True, help="Path to write narratives JSON.")
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--sleep", type=float, default=0.0, help="Seconds to sleep between requests.")
    return ap.parse_args()

def main() -> int:
    args = parse_args()

    # OpenAI SDK pointed at Ollama:
    base_url = os.environ.get("OPENAI_BASE_URL", "http://localhost:11434/v1")
    api_key  = os.environ.get("OPENAI_API_KEY", "ollama")
    client = OpenAI(base_url=base_url, api_key=api_key)

    with open(args.personas, "r", encoding="utf-8") as f:
        personas: List[Dict] = json.load(f)

    results = []
    for i, persona in enumerate(personas, start=1):
        narrative_id = str(uuid.uuid4())
        user_prompt = build_user_prompt(persona)

        # Chat Completions (Ollama supports the OpenAI-compatible endpoint)
        resp = client.chat.completions.create(
            model=args.model,
            temperature=args.temperature,
            messages=[
                {"role": "system", "content": SYS_PROMPT},
                {"role": "user",   "content": user_prompt},
            ],
        )
        text = resp.choices[0].message.content.strip()
        results.append({"narrative_id": narrative_id, "text": text, "persona": persona})

        print(f"[{i}/{len(personas)}] generated narrative_id={narrative_id}  ({len(text)} chars)")
        if args.sleep > 0:
            time.sleep(args.sleep)

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"[done] wrote {len(results)} narratives to {args.out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
