#!/usr/bin/env python3
"""
Batch inference using Ollama (OpenAI-compatible API) and flat JSON export.

Input:
  - A JSON file of narratives: [{"narrative_id": "...", "text": "..."}, ...]
  - A YAML/Markdown prompt template that contains the literal token:
        PASTE THE NARRATIVE HERE

What it does:
  - For each narrative, injects its text into the prompt template (replacing that literal token).
  - Calls an Ollama model through the OpenAI Python client (chat.completions).
  - Expects the model to return valid JSON per your schema (with "items" {...}).
  - Flattens that "items" object to:
        {
          "narrative_id": "...",
          "IT01": true|false,
          "IT01_XAI": "reason",
          "IT02": ...,
          "IT02_XAI": "...",
          ...
        }
  - Writes either JSONL (default) or JSON array (via --output-format json).

Usage example:
    python batch_infer_ollama_flat_json.py \
        --input /path/to/narratives_small.json \
        --prompt /path/to/labeling_prompt_soft.yaml \
        --output /path/to/results_flat.jsonl \
        --model llama3.1:8b \
        --base-url http://localhost:11434/v1 \
        --api-key ollama

Notes:
  - Ollama exposes an OpenAI-compatible endpoint at http://localhost:11434/v1
  - Use any local model you have pulled in Ollama (e.g., 'llama3.1', 'qwen2.5', etc.).
  - If the response isn't strictly valid JSON, we attempt a best-effort fix.
"""

import argparse
import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# pip install openai>=1.40.0
from openai import OpenAI


def load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def best_effort_json_parse(s: str) -> Optional[Dict[str, Any]]:
    """
    Try to parse a JSON object from a text that *should* be pure JSON.
    If there is extra text, try to extract the first {...} block.
    """
    s = s.strip()
    # Fast path
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to grab the outermost JSON object
    m = re.search(r"\{.*\}", s, flags=re.DOTALL)
    if m:
        chunk = m.group(0)
        try:
            return json.loads(chunk)
        except Exception:
            # Attempt to fix common JSON issues (trailing commas, bad quotes are harder)
            chunk = re.sub(r",\s*}", "}", chunk)
            chunk = re.sub(r",\s*]", "]", chunk)
            try:
                return json.loads(chunk)
            except Exception:
                return None
    return None


def flatten_items(narrative_id: str, obj: Dict[str, Any]) -> Dict[str, Any]:
    """
    Given the model's JSON (expected schema with 'items'), return the flat structure.
    """
    out = {"narrative_id": narrative_id}
    items = (obj or {}).get("items", {})
    if not isinstance(items, dict):
        return out

    for k, v in items.items():
        if not isinstance(v, dict):
            continue
        label = v.get("label", None)
        xai = v.get("xai", None)
        if label is not None:
            out[k] = bool(label)
        if xai is not None:
            out[f"{k}_XAI"] = str(xai)
    return out


def chat_complete_json(client: OpenAI, model: str, prompt_text: str, temperature: float, timeout: float) -> str:
    """
    Call the Chat Completions API and return the assistant's text.
    """
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are a careful assistant that returns ONLY valid JSON."},
            {"role": "user", "content": prompt_text},
        ],
        temperature=temperature,
        timeout=timeout,
    )
    return resp.choices[0].message.content or ""


def run(
    input_path: Path,
    prompt_path: Path,
    output_path: Path,
    model: str,
    base_url: str,
    api_key: str,
    temperature: float = 0.0,
    sleep: float = 0.0,
    max_retries: int = 3,
    timeout: float = 120.0,
    output_format: str = "jsonl",
    verbose: bool = True,
):
    client = OpenAI(base_url=base_url, api_key=api_key)

    prompt_template = load_text(prompt_path)
    records: List[Dict[str, Any]] = load_json(input_path)
    if not isinstance(records, list):
        raise ValueError("Input must be a JSON array of objects with fields: narrative_id, text")

    flat_results: List[Dict[str, Any]] = []

    with output_path.open("w", encoding="utf-8") as fo:
        for i, rec in enumerate(records, 1):
            nid = rec.get("narrative_id")
            text = rec.get("text", "")
            if not nid:
                if verbose:
                    print(f"[warn] skipping record #{i}: missing narrative_id")
                continue

            prompt = prompt_template.replace("PASTE THE NARRATIVE HERE", text)

            last_err = None
            assistant_text = ""
            parsed = None
            for attempt in range(1, max_retries + 1):
                try:
                    if verbose:
                        print(f"[{i}/{len(records)}] {nid}  (try {attempt}/{max_retries})")
                    assistant_text = chat_complete_json(
                        client=client,
                        model=model,
                        prompt_text=prompt,
                        temperature=temperature,
                        timeout=timeout,
                    )
                    parsed = best_effort_json_parse(assistant_text)
                    if parsed is None:
                        raise ValueError("Model response was not valid JSON.")
                    break
                except Exception as e:
                    last_err = e
                    if verbose:
                        print(f"   -> error: {e}")
                    time.sleep(min(2.0 * attempt, 6.0))

            if parsed is None:
                if verbose:
                    print(f"[error] failed to parse JSON for {nid}: {last_err}")
                # Still write a row with raw text in case you want to inspect
                flat = {"narrative_id": nid, "_error": str(last_err), "_raw": assistant_text}
            else:
                flat = flatten_items(nid, parsed)

            flat_results.append(flat)

            if output_format == "jsonl":
                fo.write(json.dumps(flat, ensure_ascii=False) + "\n")

            if sleep > 0:
                time.sleep(sleep)

    if output_format == "json":
        output_path.write_text(json.dumps(flat_results, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[done] wrote {len(flat_results)} rows to: {output_path}")


def parse_args(argv: List[str]) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Batch inference via Ollama with flat JSON export")
    ap.add_argument("--input", required=True, help="Path to narratives JSON array")
    ap.add_argument("--prompt", required=True, help="Path to prompt template (YAML/MD/TXT)")
    ap.add_argument("--output", required=True, help="Where to write results (.jsonl or .json)")
    ap.add_argument("--model", required=True, help="Ollama model name, e.g., 'llama3.1:8b'")
    ap.add_argument("--base-url", default="http://localhost:11434/v1", help="OpenAI-compatible base URL (Ollama)")
    ap.add_argument("--api-key", default="ollama", help="API key (Ollama ignores but required by client)")
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--sleep", type=float, default=0.0)
    ap.add_argument("--max-retries", type=int, default=3)
    ap.add_argument("--timeout", type=float, default=120.0)
    ap.add_argument("--output-format", choices=["jsonl", "json"], default="jsonl", help="Write JSONL or a JSON array")
    ap.add_argument("--quiet", action="store_true", help="Reduce logging")
    args = ap.parse_args(argv)
    args.verbose = not args.quiet
    return args


def main(argv: List[str] = None):
    ns = parse_args(sys.argv[1:] if argv is None else argv)
    run(
        input_path=Path(ns.input),
        prompt_path=Path(ns.prompt),
        output_path=Path(ns.output),
        model=ns.model,
        base_url=ns.base_url,
        api_key=ns.api_key,
        temperature=ns.temperature,
        sleep=ns.sleep,
        max_retries=ns.max_retries,
        timeout=ns.timeout,
        output_format=ns.output_format,
        verbose=ns.verbose,
    )


if __name__ == "__main__":
    main()
